-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Apr 04, 2020 at 01:27 PM
-- Server version: 5.7.29-0ubuntu0.16.04.1
-- PHP Version: 7.0.33-0ubuntu0.16.04.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_ldlpadalaexpress`
--

-- --------------------------------------------------------

--
-- Table structure for table `tbl_ldlpadalaexpress`
--

CREATE TABLE `tbl_ldlpadalaexpress` (
  `id_no` int(11) NOT NULL,
  `txn_no` varchar(256) NOT NULL,
  `status` varchar(256) NOT NULL,
  `amt` varchar(256) NOT NULL,
  `sender` varchar(256) NOT NULL,
  `sender_cp_no` varchar(256) NOT NULL,
  `dest` varchar(256) NOT NULL,
  `receiver` varchar(256) NOT NULL,
  `receiver_cp_no` varchar(256) NOT NULL,
  `relship` varchar(256) NOT NULL,
  `purp` varchar(256) NOT NULL,
  `date_time_sent` varchar(256) NOT NULL,
  `date_time_claimed` varchar(256) NOT NULL,
  `processed_by` varchar(256) NOT NULL,
  `released_by` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tbl_ldlpadalaexpress`
--

INSERT INTO `tbl_ldlpadalaexpress` (`id_no`, `txn_no`, `status`, `amt`, `sender`, `sender_cp_no`, `dest`, `receiver`, `receiver_cp_no`, `relship`, `purp`, `date_time_sent`, `date_time_claimed`, `processed_by`, `released_by`) VALUES
(1, '040320023949', 'Claimed', '1000', 'Lorence Laudenio', '09488157847', 'Occidental Mindoro', 'Merlinda Laudenio', '09463979644', 'Family', 'Allowance', '04/03/20 02:39:49', '04/03/20 08:57:26', '', 'erika - '),
(2, '040320032205', 'Claimed', '500', 'Lorence Laudenio', '09488157847', 'Kalibo', 'Ervel Laudenio', '09272053904', 'Family', 'Allowance', '04/03/20 03:22:05', '04/03/20 09:11:56', 'noname', 'erika - '),
(3, '040320032351', 'Claimed', '600', 'Lorence Laudenio', '09488157847', 'Calintaan', 'Ryan Laudenio', '09272053904', 'Fa', 'Allowance', '04/03/20 03:23:51', '04/03/20 09:05:17', 'noname', 'erika - '),
(4, '040320033913', 'Claimed', '400', 'Lorence Laudenio', '09488157847', 'San Jose', 'Jesa Laudenio', '09272053904', 'Family', 'Allowance', '04/03/20 03:39:13', '04/03/20 09:05:58', 'admin', 'erika - '),
(5, '040320034250', 'Claimed', '2000', 'Lorence Laudenio', '09488157847', 'Lumintao', 'Avelito Laudenio', '09272053904', 'Family', 'Kahoy', '04/03/20 03:42:50', '04/03/20 03:43:11', 'lorence', 'admin'),
(6, '040320084701', 'Claimed', '5000', 'Erika Embang', '09488157847', 'Negros Occidental', 'Lorence Laudenio', '09272053904', 'Friend', 'Utang', '04/03/20 08:47:01', '04/03/20 08:52:14', 'admin - ', 'erika - '),
(7, '040320093808', 'Claimed', '1000', 'Lorence Laudenio', '09488157847', 'Kalibo', 'Avelito Laudenio', '09272053904', 'Family', 'Allowance', '04/03/20 09:38:08', '04/03/20 09:39:06', 'admin - ', 'lorence - '),
(8, '040320095828', 'Claimed', '5000', 'Jake Vargas', '09488157847', 'Manila', 'Julianne San Jose', '09272053904', 'GF', 'Makeup', '04/03/20 09:58:28', '04/03/20 10:01:12', 'admin - ', 'admin - '),
(9, '040320100445', 'Claimed', '3000', 'Julius Cesar', '09488157847', 'San Jose', 'Anne Taytay', '09272053904', 'Classmate', 'Allowance', '04/03/20 10:04:45', '04/03/20 10:05:20', 'admin - ', 'lorence - '),
(10, '040320102727', 'Claimed', '600', 'Lorence Laudenio', '09488157847', 'Rizal', 'Vincent Payas', '09272053904', 'Classmate', 'Load', '04/03/20 10:27:27', '04/03/20 10:28:11', 'lorence - mindoro', 'admin - palawan'),
(11, '040320103916', 'Claimed', '400', 'vice ganda', '09488157847', 'quezon', 'lorence laudenio', '09272053904', 'fan', 'friend', '04/03/20 10:39:16', '04/04/20 01:11:04', 'admin - palawan', 'lorence - mindoro'),
(12, '040420010035', 'Unclaim', '400', 'Lorence Laudenio', '09488157847', 'Paranaque', 'Joem Bascon', '09272053904', 'Friend', 'Allowance', '04/04/20 01:00:35', '', 'admin - palawan', ''),
(13, '040420010148', 'Unclaim', '8000', 'Lorence Laudenio', '09488157847', 'Makati', 'Mel Tiangco', '09272053904', 'Client', 'Advertisement', '04/04/20 01:01:48', '', 'admin - palawan', ''),
(14, '040420011900', 'Unclaim', '200', 'Lorence Laudenio', '09488157847', 'Gil Puyat', 'Dano Tingcongco', '09272053904', 'Friend', 'Cellphone', '04/04/20 01:19:00', '', 'lorence - mindoro', '');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `tbl_ldlpadalaexpress`
--
ALTER TABLE `tbl_ldlpadalaexpress`
  ADD PRIMARY KEY (`id_no`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tbl_ldlpadalaexpress`
--
ALTER TABLE `tbl_ldlpadalaexpress`
  MODIFY `id_no` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
