<br>
<div align="center">
<small>Copyright &copy; <?php echo date("Y");?> <a href="about.php">ALREJJ Group of Companiess</a></small>
</div>


