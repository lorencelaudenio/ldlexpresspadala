<?php 
include("global_variables.php");
include("headers.php");
?>
<div class="container">
<footer class="page-footer font-small blue">
<div class="row">
  <div class="col footer-copyright text-left py-3"><small><p>Express your money padala.</small></p></div>
  <div class="col footer-copyright text-right py-3"><small>Copyright &copy; <?php echo date("Y");?> <a href="about.php"><?php echo $g_receipttitle;?></a></small></div>
  </div>
 </footer>
</div>


