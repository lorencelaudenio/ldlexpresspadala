<?php

if(isset($_POST['login'])){
	session_start();
	$_SESSION['user'] = $_POST['username'];
	header("Location: index.php");
}
?>

Login:
<form method="POST" action="login.php">
Username:<input type="text" name="username">
<input type="submit" name="login" value="Login">
</form>