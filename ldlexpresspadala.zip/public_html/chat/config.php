<?php
/*

	Database config settings:

*/
$database = array(
	"host" 		=> 	"localhost",
	"username" 	=> 	"id13211271_user_lorence",
	"password" 	=> 	"04072020Ldl",
	
	//only edit if you changed the actual database name
	"database" 	=> 	"id13211271_db_ldlexpress"
);