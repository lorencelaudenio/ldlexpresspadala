<?php

if($_POST["text"] != "") {
	require("mysql.php");
	include ("conn.php");
	
	$origin = $g_logged_info;
	$msg = $db->clean($_POST["text"]);

	$sql = "INSERT INTO chat (origin, message) VALUES ('$origin', '$msg')";
	$db->query($sql);
}
