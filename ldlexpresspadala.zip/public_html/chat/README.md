# Simple-chat
Simple chat made with HTML, PHP, jQuery, Bootstrap 3 and MySQL

Install:
- Import database.sql.
- Edit config.php to match your MySQL server.